def perimeter(length, width):
	perimeter = (2*length) + (2*width)
	return perimeter
	
def area (length, width):
	return length * width
