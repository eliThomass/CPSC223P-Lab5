def surface_area(side):
	return side * side * 6
	
def volume(side):
	return side * side * side
