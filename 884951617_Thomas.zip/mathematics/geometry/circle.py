def circumference(radius):
	return 2 * 3.14159 * radius
