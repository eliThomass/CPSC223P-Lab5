def addition(left, right):
	return left + right
	
def subtraction(left, right):
	return left - right

def multiplication(left, right):
	return left * right
	
def division(left, right):
	return left / right
